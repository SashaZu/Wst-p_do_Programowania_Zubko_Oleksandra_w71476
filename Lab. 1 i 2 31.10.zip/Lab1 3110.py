#Lab1

#Zadanie 8
#wiek >= 18 -> dorosły

"""
wiek = int(input("Ile masz lat? "))

#debug
#print(wiek)
#print(type(wiek))

if wiek>= 18 and wiek<=150:
    print("Osoba dorosła")
elif wiek<0 or wiek >=150 :
    print("Napisz poprawny wiek")
else:
    print("Dziecko")
"""

#Zadanie 9
"""
wiek = int(input("Ile masz lat? "))

if wiek>0 and wiek<=150:
    if wiek <=4:
        print("Wstęp jest za darmo")
    elif wiek>4 and wiek<18:
        print("koszt biletu 10zł")
    else:
        student = input("Czy jesteś studentem?")
        if student == "Tak":
            print("Koszt biletu jest 15 zł")
        else:
            print("Koszt biletu 20 zł")
else:
    print("Napisz poprawny wiek")
"""

#Zadanie 10
'''
x = float(input("Podaj pierwszą liczbę: "))
y = float(input("Podaj drugą liczbę: "))
z = float(input("Podaj trzecią liczbę: "))

liczby = [x, y, z]

for i in range(len(liczby)):
    for j in range(0, len(liczby) - i - 1):
        if liczby[j] > liczby[j + 1]:

            liczby[j], liczby[j + 1] = liczby[j + 1], liczby[j]

print("Posortowane liczby od najmniejszej do największej: ")
print(liczby[0], liczby[1], liczby[2])
'''

#Zadanie 11
'''
import math

a = float(input("Podaj współczynnik a: "))
b = float(input("Podaj współczynnik b: "))
c = float(input("Podaj współczynnik c: "))

if a == 0:
    print("To nie jest równanie kwadratowe.")
else:
    delta = b ** 2 - 4 * a * c

    if delta < 0:
        print("Równanie nie ma rozwiązań w zbiorze liczb rzeczywistych.")
    elif delta == 0:
        x = -b / (2 * a)
        print(f"Równanie ma jedno rozwiązanie: x = {x}")
    else:
        x1 = (-b + math.sqrt(delta)) / (2 * a)
        x2 = (-b - math.sqrt(delta)) / (2 * a)
        print(f"Równanie ma dwa rozwiązania: x1 = {x1}, x2 = {x2}")
'''

#Zadanie 12

#A
'''
def a(x):
    if x > 0:
        return 2 * x
    elif x == 0:
        return 0
    else:
        return -3 * x

try:
    x = float(input("Wpisz poprawne liczby for x: "))

    print(f"a({x}) = {a(x)}")

except ValueError:
    print("Wpisz poprawne liczby.")
'''

'''
def b(x):
    if x >= 1:
        return x ** 2
    else:
        return x

try:
    x = float(input("Wpisz poprawne liczby for x: "))

    print(f"b({x}) = {b(x)}")

except ValueError:
    print("Wpisz poprawne liczby.")
'''

'''
def c(x):
    if x > 2:
        return 2 + x
    elif x == 2:
        return 8
    else:
        return x - 4

try:
    x = float(input("Wpisz poprawne liczby for x: "))

    print(f"c({x}) = {c(x)}")

except ValueError:
    print("Wpisz poprawne liczby.")
'''

#Zadanie 13
'''
liczba1 = float(input("Podaj pierwszą liczbę: "))
liczba2 = float(input("Podaj drugą liczbę: "))

print("Wybierz operację:")
print("1. Dodawanie")
print("2. Odejmowanie")
print("3. Mnożenie")
print("4. Dzielenie")
operacja = input("Wpisz numer operacji (1/2/3/4): ")

if operacja == '1':
    wynik = liczba1 + liczba2
    print(f"Wynik dodawania: {wynik}")
elif operacja == '2':
    wynik = liczba1 - liczba2
    print(f"Wynik odejmowania: {wynik}")
elif operacja == '3':
    wynik = liczba1 * liczba2
    print(f"Wynik mnożenia: {wynik}")
elif operacja == '4':
    if liczba2 != 0:
        wynik = liczba1 / liczba2
        print(f"Wynik dzielenia: {wynik}")
    else:
        print("Błąd: Dzielenie przez zero!")
else:
    print("Nieprawidłowy wybór operacji.")
'''
#Instrukcja switch, która istnieje w wielu innych językach programowania,
# pozwala na łatwiejsze zarządzanie wieloma przypadkami wyboru, działając jak lista opcji.
#Python natomiast nie posiada switch, więc często stosuje się sekwencję if-elif dla uzyskania podobnego efektu.

#Zadanie 14
'''
def czy_plik_excel(nazwa_pliku):
    return nazwa_pliku.endswith(('.xls', '.xlsx'))

nazwa_pliku = "dane_finansowe.xlsx"
print(czy_plik_excel(nazwa_pliku))
'''
#Metoda .endswith() sprawdza, czy tekst kończy się na podany znak lub grupę znaków i zwraca Prawda lub Fałsz.

#Zadanie 15
'''
def rozwiązanie_równania_liniowego():
    a = float(input("Podaj współczynnik a: "))
    b = float(input("Podaj współczynnik b: "))

    if a == 0:
        if b == 0:
            print("Równanie ma nieskończenie wiele rozwiązań.")
        else:
            print("Równanie nie ma rozwiązania.")
    else:
        x = -b / a
        print(f"Rozwiązanie równania: x = {x}")

rozwiązanie_równania_liniowego()
'''

#Zadanie 16
'''
import math

a = float(input("Podaj długość boku a: "))
b = float(input("Podaj długość boku b: "))
c = float(input("Podaj długość boku c: "))

obwod = a + b + c

p = (a + b + c) / 2

pole = math.sqrt(p * (p - a) * (p - b) * (p - c))

print(f"Obwód trójkąta wynosi: {obwod}")
print(f"Pole trójkąta wynosi: {pole:.2f}")
'''

#Zadanie 17
'''
def sprawdz_wielkosc_litery(litera):
    if len(litera) != 1:
        return "Proszę wprowadzić tylko jeden znak."

    if litera.isupper():
        return "To jest wielka litera."
    elif litera.islower():
        return "To jest mała litera."
    else:
        return "To nie jest litera."

litera = input("Wprowadź jedną literę: ")

wynik = sprawdz_wielkosc_litery(litera)
print(wynik)
'''

#Zadanie 19
'''
litera = input("Podaj literę: ")

if litera.islower():
    zamieniona_litera = litera.upper()
else:
    zamieniona_litera = litera.lower()

print("Zamieniona litera:", zamieniona_litera)
'''
#W kodzie ASCII każda litera ma przypisany inny numer.
# Małe litery (a-z) mają numery od 97 do 122, a duże litery (A-Z) mają numery od 65 do 90.
# Różnica między małą a dużą literą wynosi 32.

#Zadanie 20
'''
def oblicz_wynik(gol, bonus):
    wynik = gol * 10

    if gol > 10:
        bonus += 10
    if gol > 5:
        bonus += 5

    wynik += bonus

    return wynik

gol = int(input("Podaj liczbę strzelonych bramek: "))
bonus = int(input("Podaj liczbę punktów bonusowych: "))

wynik = oblicz_wynik(gol, bonus)
print(f"Łączny wynik drużyny: {wynik} punktów")
'''