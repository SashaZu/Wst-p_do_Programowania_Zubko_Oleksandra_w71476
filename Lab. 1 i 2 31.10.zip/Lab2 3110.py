#Lab2

#Zadanie 1
"""
#A
for i in range(1, 101):
   print(i)

#B
for i in range(100, -1, -1):
    print(i)

#C
for i in range(7, 78, 7):
    print(i)

#D
for i in range(20, -1, -2):
    print(i)
"""

#Zadanie 2
'''
x = int(input("Podaj rozmiar kwadratu: "))\
'''
#A
'''
for j in range(x):
    for i in range(x):
        print("*", end=" ")
    print("")
'''
#B
'''
for j in range(x):
    for i in range(j+1):
        print("*", end=" ")
    print("")
'''

#C
'''
for j in range(x):

    for k in range(x - j - 1):
        print(" ", end="")
    for i in range(j+1):
        print("*", end=" ")
    print("")
'''

#Zadanie 3
'''
def ciag_arytmetyczny(n, a, r):
    for i in range(n):
        element = a + i * r
        print(f'Element {i + 1}: {element}')

n = int(input("Wprowadź liczbę naturalną n: "))
a = float(input("Wprowadź pierwszy element a (liczba rzeczywista): "))
r = float(input("Wprowadź różnicę r (liczba rzeczywista): "))

if n < 1:
    print("Liczba n musi być liczbą naturalną (n >= 1).")
else:
    ciag_arytmetyczny(n, a, r)
'''

#Zadanie 4
'''
def silnia(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * silnia(n - 1)

n = int(input("Podaj liczbę naturalną n: "))

if n < 0:
    print("Silnia jest zdefiniowana tylko dla liczb naturalnych (n >= 0).")
else:
    wynik = silnia(n)
    print(f"Silnia {n} wynosi: {wynik}")
'''

#Zadanie 5
'''
tekst = "Rzeszów jest piękny"

#A
print(tekst[0])

#B
print(tekst[6], tekst[9], tekst[12], tekst[1])
'''

'''
print(tekst[6])
print(tekst[0 : 7])
print(tekst[0 :  : 2])
print(tekst[-2])
print(tekst[9 : ])
print(tekst[-1 :  : -1])
'''

#Zadanie 6
'''
tresc = "Python jest super"
#A
print(tresc[0])
#B
print(tresc[-1])
#C
print(tresc[ : : 2])
#D
print(tresc[1 : : 3])
#E
print(tresc[9 : ])
#F
print(tresc[ : : -1])
'''

#Zadanie 7
'''
#A
imie = input("Podaj swoje imię: ")
print(f"Witaj {imie}")
#B
wiek = int(input("Podaj swój wiek: "))
print(f"Twój wiek to: {wiek}")
#C
imie_nazwisko = input("Podaj swoje imię i nazwisko: ")
imie, nazwisko = imie_nazwisko.split()
inicjaly = imie[0].upper() + nazwisko[0].upper()
print(f"Inicjały: {inicjaly}")
#D
lancuch = input("Podaj łańcuch: ")
print(lancuch * 5)
#E
lancuch1 = input("Podaj pierwszy łańcuch: ")
lancuch2 = input("Podaj drugi łańcuch: ")
lancuch3 = lancuch1 + lancuch2
print(f"Połączony łańcuch: {lancuch3}")
#F
lancuch1 = input("Podaj pierwszy łańcuch: ")
lancuch2 = input("Podaj drugi łańcuch: ")
polowa1 = lancuch1[:len(lancuch1)//2]
polowa2 = lancuch2[len(lancuch2)//2:]
lancuch4 = polowa1 + polowa2
print(f"Połączona połowa: {lancuch4}")
'''