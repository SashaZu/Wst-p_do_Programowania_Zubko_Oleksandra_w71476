def kwadrat(x):
    return x ** 2

def szescian(x):
    return x ** 3

def dodaj(a, b):
    return a + b