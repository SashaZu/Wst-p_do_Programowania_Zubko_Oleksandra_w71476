#Zadanie 1
"""
import random

#A
szczęśliwy_numerek = random.randint(1, 20)
print(f"Szczęśliwy_numerek: {szczęśliwy_numerek}")

#B
roczniki = [2004, 2005, 2006, 2007]
szczęśliwy_rocznik = random.choice(roczniki)
print(f"Szczęśliwy rocznik: {szczęśliwy_rocznik}")

#C
lotto_liczby = random.sample(range(1, 50), 6)
print(f"Wylosowane liczby z dużego lotka: {lotto_liczby}")
"""

#Zadanie 2
'''
import math
#A
print(math.sqrt(81))
#B
print(math.pow(8, 10))
#C
print(math.sqrt(2)+math.sqrt(3)+math.sqrt(6))
#D
"print(math.sqrt(-5))" "Bląd"
#E
print(math.pow(125, 1/3))
'''

#Zadanie 3
'''
def sekundnik(czas):
    while czas > 0:
        print(f"Pozostało: {czas} sekund")
        time.sleep(1)
        czas -= 1
    print("Czas upłynął!")

czas = int(input("Podaj czas w sekundach: "))
sekundnik(czas)
'''

#Zadanie 4
'''
from datetime import datetime, timedelta

def ile_dni():
    ostatnie_laboratoria = datetime(2024, 11, 21)
    kolokwium = datetime(2025, 1, 9)

    dzisiaj = datetime.now()
    dni_od_laboratoriów = (dzisiaj - ostatnie_laboratoria).days
    dni_do_kolokwium = (kolokwium - dzisiaj).days

    print(f"Od ostatnich laboratoriów ({ostatnie_laboratoria.strftime('%d %B %Y')}) mineło {dni_od_laboratoriów} dni.")
    print(f"Do kolokwium ({kolokwium.strftime('%d %B %Y')}) pozostało {dni_do_kolokwium} dni.")

ile_dni()
'''

#Zadanie 5
'''
import keyword

print(f"for to keyword: {keyword.iskeyword("for")}")
print(f"print to keyword {keyword.iskeyword("print")}")
print(f"break to keyword: {keyword.iskeyword("break")}")
print(f"done to keyword: {keyword.iskeyword("done")}")
print(f"bad to keyword: {keyword.iskeyword("bad")}")
'''

#Zadanie 6
'''
import math
import keyword

print(dir(math))
print(dir(keyword))
print(dir(tuple))
'''

#Zadanie 7
'''
import geometria

promien = 16

obwod = geometria.obwod_kola(promien)
pole = geometria.pole_kola(promien)

print(f"Obwd koa o promienu {promien} wynosi: {obwod}")
print(f"Pole koa o promieniu {promien} wynosi: {pole}")
'''

#Zadanie 8
'''
import temperatura

print(f"21 stopni Celsjusza na Fahrenheita: {temperatura.c_to_f(21)}")
print(f"89 stopni Farenheita na Celjusza: {temperatura.f_to_c(89)}")
print(f"35 stopni Celsjusza na Kelwiny: {temperatura.c_to_k(35)}")
'''

#Zadanie 9
'''
import f_mat

kwadrat_10 = f_mat.kwadrat(10)
print(f"Kwadrat liczby 10 to: {kwadrat_10}")

szescian_3 = f_mat.szescian(3)
print(f"Sześcian liczby 3 to: {szescian_3}")

suma = f_mat.dodaj(10, 5)
print(f"Suma liczb 10 i 5 to: {suma}")

from f_mat import kwadrat, szescian, dodaj

kwadrat_10_2 = kwadrat(10)
print(f"Kwadrat liczby 10 (importowane wybranie) to: {kwadrat_10_2}")

szescian_3_2 = szescian(3)
print(f"Sześcian liczby 3 (importowane wybranie) to: {szescian_3_2}")

suma_2 = dodaj(10, 5)
print(f"Suma liczb 10 i 5 (importowane wybranie) to: {suma_2}")
'''

#Zadanie 10
'''
import random
from math import prod, pow

start = int(input("Podaj pocątek przedziału: "))
end = int(input("Podaj koniec przedziału: "))

przedział = start and end

if start < end and przedział >= 0:
    krotka = tuple(random.randint(start, end) for _ in range(10))
    srednia_geometryczna = pow(prod(krotka), 1 / len(krotka))
    print("Wygerowana krotka: ", krotka)
    print("Średnia geometryczna: ", srednia_geometryczna)
else:
    print("Podaj poprawne liczby.")
'''

#Zadanie 11
'''
import random

def guessing_game():
    print("Witaj w grze w zgadywanie liczby!")

    while True:
        try:
            min_range = int(input("Podaj minimalny zakres (liczba całkowita): "))
            max_range = int(input("Podaj maksymalny zakres (liczba całkowita): "))

            if max_range - min_range < 10:
                print("Zakres musi być co najmniej 10 liczb szeroki. Spróbuj ponownie.")
                continue
            break
        except ValueError:
            print("Podano nieprawidłową wartość. Proszę wprowadzić liczby całkowite.")

    secret_number = random.randint(min_range, max_range)
    print(f"Wylosowano liczbę z zakresu {min_range} - {max_range}. Masz 3 próby, aby ją zgadnąć!")

    attempts = 3
    while attempts > 0:
        try:
            guess = int(input(f"Podaj swoją próbę (pozostało prób: {attempts}): "))

            if guess < min_range or guess > max_range:
                print(f"Liczba musi być w zakresie {min_range} - {max_range}. Spróbuj ponownie.")
                continue

            if guess < secret_number:
                print("Za mało!")
            elif guess > secret_number:
                print("Za dużo!")
            else:
                print("Gratulacje! Zgadłeś liczbę!")
                break

            attempts -= 1
        except ValueError:
            print("Proszę podać liczbę całkowitą.")

    if attempts == 0:
        print(f"Przegrałeś/łaś! Wylosowana liczba to {secret_number}.")

if __name__ == "__main__":
    guessing_game()
'''
#Zadanie 12
'''
import math

def is_acute_angle(angle: float) -> bool:
    return 0 < angle < 90

def triangle_exists(a: float, b: float, angle: float) -> bool:
    if a <= 0 or b <= 0:
        return False
    if not is_acute_angle(angle):
        return False
    return True

def calculate_triangle_area(a: float, b: float, angle: float) -> float:

    if not triangle_exists(a, b, angle):
        raise ValueError("Podane dane są nieprawidłowe lub trójkąt nie jest ostrokątny.")
    angle_radians = math.radians(angle)

    area = 0.5 * a * b * math.sin(angle_radians)
    return area

if __name__ == "__main__":
    try:
        print("Obliczanie pola trójkąta ostrokątnego:")
        a = float(input("Podaj długość pierwszego boku (a): "))
        b = float(input("Podaj długość drugiego boku (b): "))
        angle = float(input("Podaj kąt między bokami (w stopniach): "))

        area = calculate_triangle_area(a, b, angle)
        print(f"Pole trójkąta wynosi: {area:.2f}")
    except ValueError as e:
        print(f"Błąd: {e}")
'''

#Zadanie 13
'''
from datetime import datetime, timedelta

def przetworz_date():
    try:
        rok = int(input("Podaj rok (np. 2024): "))
        if rok <= 1970:
            print("Błąd: Rok musi być późniejszy niż 1970. Podaj poprawny rok.")
            return

        miesiac = int(input("Podaj miesiąc (1-12): "))
        dzien = int(input("Podaj dzień (1-31): "))

        wprowadzona_data = datetime(rok, miesiac, dzien)

        #A
        dzien_roku = wprowadzona_data.timetuple().tm_yday
        print(f"Dzień roku: {dzien_roku}")

        #B
        numer_tygodnia = wprowadzona_data.isocalendar().week
        print(f"Numer tygodnia: {numer_tygodnia}")

        #C
        data_minus_2_tygodnie = wprowadzona_data - timedelta(weeks=2)
        data_plus_2_tygodnie = wprowadzona_data + timedelta(weeks=2)
        print(f"Data na 2 tygodnie przed: {data_minus_2_tygodnie.strftime('%Y-%m-%d')}")
        print(f"Data na 2 tygodnie po: {data_plus_2_tygodnie.strftime('%Y-%m-%d')}")

        #D
        dni_do_niedzieli = (6 - wprowadzona_data.weekday()) % 7
        najblizsza_niedziela = wprowadzona_data + timedelta(days=dni_do_niedzieli)
        print(f"Data najbliższej niedzieli: {najblizsza_niedziela.strftime('%Y-%m-%d')}")

        #E
        czas_unixowy = int(wprowadzona_data.timestamp())
        print(f"Czas unixowy dla podanej daty: {czas_unixowy}")

    except ValueError:
        print("Błąd: Podane dane są nieprawidłowe. Sprawdź miesiąc i dzień.")

przetworz_date()


#Moduł, który może mi się przydać: do obsługi dat i czasu w Pythonie najlepiej użyć modułu datetime.
#Mogę również skorzystać z modułu time do obliczenia czasu unixowego (liczba sekund od 1 stycznia 1970 roku, UTC).
#Działania matematyczne na datach: Python pozwala wykonywać operacje na obiektach daty i czasu za pomocą operatorów dodawania
# i odejmowania oraz funkcji takich jak timedelta.
#Czas unixowy: jest to liczba sekund, która upłynęła od 1 stycznia 1970 roku o godzinie 00:00:00 UTC.
'''