PI = 3.14159

def obwod_kola(promien):
    return 2 * PI * promien

def pole_kola(promien):
    return PI * promien ** 2