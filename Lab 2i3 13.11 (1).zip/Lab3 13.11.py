# Lab3
# Zadanie 1
"""
imiona=["Katia", "Sasha", "Maksym", "Basia" ]
#A
posortowane=sorted(imiona)
#print(imiona)
#print(posortowane)

#B
imiona.append("Wadym")
imiona.append("Zosia")

ostatni=imiona.pop()
print(ostatni)
#C
imiona.insert(2,"Ola")

#D
imiona.reverse()


for imie in imiona *2 :
    print(imie, end= " ")
"""

# Zadanie 2
'''
import string

zdanie = input("Podaj zdanie: ")
'''
# A
''''
litery_w_zdaniu = set(c.lower() for c in zdanie if c.isalpha())
alfabet = set(string.ascii_lowercase)
litery_posortowane = sorted(litery_w_zdaniu)
brakujace_litery = sorted(alfabet - litery_w_zdaniu)

print("Litery w zdaniu (w kolejności alfabetycznej):", "".join(litery_posortowane))
print("Brakujące litery:", "".join(brakujace_litery))
'''
# B
''''
zdanie_bez_nieparzystych = zdanie[::2]
print("Zdanie bez znaków o nieparzystych indeksach:", zdanie_bez_nieparzystych)
'''
# C
'''
wyrazy = zdanie.split()
zdanie_z_wyrazami_wielkimi = " ".join(wyraz.capitalize()[:-1] + wyraz[-1].upper() if len(wyraz) > 1 else wyraz.upper() for wyraz in wyrazy)
print("Zdanie z wyrazami zaczynającymi i kończącymi się wielką literą:", zdanie_z_wyrazami_wielkimi)
'''
# D
'''
wyrazy = zdanie.split()
najdluzsze_slowo = max(wyrazy, key=len)
print("Najdłuższe słowo:", najdluzsze_slowo)
print("Długość najdłuższego słowa:", len(najdluzsze_slowo))
'''
# E
'''
wystapienia = {}
nowe_zdanie = []
for znak in zdanie:
    if znak in wystapienia:
        nowe_zdanie.append('@')
    else:
        nowe_zdanie.append(znak)
        wystapienia[znak] = 1
nowe_zdanie = "".join(nowe_zdanie)
print("Zdanie po zamianie powtarzających się znaków na '@':", nowe_zdanie)
'''

# Zadanie 3
'''
def is_palindrome(text):
    cleaned_text = ''.join(char.lower() for char in text if char.isalnum())
    return cleaned_text == cleaned_text[::-1]

user_input = input("Podaj ciąg znaków: ")

if is_palindrome(user_input):
    print("Podany ciąg jest palindromem.")
else:
    print("Podany ciąg nie jest palindromem.")
'''

# Zadanie 4
'''
krotka = ("ktaf", "gfwgk", "hkiksd", "ljkthykt")
suma=0
liczbak=0
liczbakt=0
maxznaki=int(input("podaj maksymalną dLugość słowa"))

for slowo in krotka:
    #A
    suma+=len(slowo)
    #B
    for znak in slowo:
        if znak=="k":
            liczbak+=1
    #C
    if slowo.find("kt") >= 0:
        liczbakt+=1
        #co kiedy jest wiele podciagów w jednym słowie

    if len(slowo)<= maxznaki: liczbaslow+=1

print(suma)
print(liczbak)
print(liczbakt)
'''

# Zadanie 5
'''
listaZakupow={"mleko":3.5, "chleb":4, "kiłbasa":20, "piwo":4, "papierosy":17.5}

for element in listaZakupow:
    print(f"Na liście jest {element} za {listaZakupow[element]} zł")
    #zmienna pomocnicza sumy
    # +=lista[el]
print(sum(listaZakupow.values()))
'''

#Zadanie 6
'''
rachunki = {
    "maj": 250,
    "czerwiec": 220,
    "lipiec": 300,
    "sierpień": 270,
    "wrzesień": 310,
    "październik": 290
}

maksymalny_rachunek = max(rachunki.values())
minimalny_rachunek = min(rachunki.values())
suma_rachunków = sum(rachunki.values())
średnia_rachunków = suma_rachunków / len(rachunki)

print(f"Maksymalny rachunek: {maksymalny_rachunek} zł")
print(f"Minimalny rachunek: {minimalny_rachunek} zł")
print(f"Suma rachunków: {suma_rachunków} zł")
print(f"Średnia rachunków: {średnia_rachunków:.2f} zł")

ostatni_miesiąc = list(rachunki.keys())[-1]
ostatni_rachunek = rachunki[ostatni_miesiąc]

if ostatni_rachunek > średnia_rachunków:
    print(f"Rachunek za {ostatni_miesiąc} wynosi {ostatni_rachunek} zł. Trzeba zacisnąć pasa.")
else:
    print(f"Rachunek za {ostatni_miesiąc} wynosi {ostatni_rachunek} zł. Wszystko okay.")
'''

# Zadanie 7
'''
X={3,5,1,8,-9}
Y={3,5,2,-8,0}

#A
print(5 in X)
#B
print (X.issubset(Y))
#D
print(X.union(Y))
#E
print(X.difference(Y))
#G
print(X.intersection(Y))
#H
print(max(X))
#I
a=X.pop()
print()
Y.add(a)
print(X)
print(Y)
#J
#1. interacja po elementach X
Y=(X.union(Y))
print(Y)
#K
X.clear()
print(X)
'''

#Zadanie 8
'''
import random

input_string = input("Podaj pięć cyfr oddzielonych przecinkami: ")
#A
numbers = input_string.split(",")
#B
if len(numbers) != 5:
    print("Nie podałeś dokładnie pięciu cyfr. Program zakończył działanie.")
    exit()

try:
    numbers = [int(num.strip()) for num in numbers]
except ValueError:
    print("Wprowadzone dane muszą być liczbami. Program zakończył działanie.")
    exit()
#C
numbers_set = set(numbers)
random_element = random.choice(list(numbers_set))
#D
if random_element == min(numbers):
    print(f"Wylosowana liczba {random_element} jest najmniejszą z podanych.")
elif random_element == max(numbers):
    print(f"Wylosowana liczba {random_element} jest największą z podanych.")
else:
    print(f"Wylosowana liczba to {random_element}. Nie jest ani najmniejsza, ani największa.")
'''

#Zadanie 9
'''
rows = 6
cols = 5

enemies = [(0,1), (2,3), (2,4), (3,4)]

coins = [(1,1), (2,0), (3,3), (5,3)]

river_y = 2

for y in range(rows):
    for x in range(cols):
        if (y, x) in enemies:  
            print("x", end="") #przeciwnicy
        elif (y, x) in coins:  
            print("*", end="") #monety
        elif y == river_y:  
            print("=", end="") #rzeka
        else:  
            print(".", end="") #trawa
    print()
'''

#Zadanie 11
'''
import string

def podziel_liste(n):
    alfabet = list(string.ascii_lowercase)

    podzielona_lista = [alfabet[i:i + n] for i in range(0, len(alfabet), n)]

    return podzielona_lista

n = int(input("Podaj wartość n: "))

wynik = podziel_liste(n)
print(wynik)
'''