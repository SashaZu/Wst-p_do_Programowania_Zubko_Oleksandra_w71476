#Zadanie 8
#𝑥∈[−4,4]
#krokiem 0.5
"""
x=-4
while x <= 4:
    y=2*x*x-5*x-8
    print(f"Dla x= {x} funkcja ma wartość {y}")
    x+=0.5
#Iteratorem będzie wartość x, która zmienia się od -4 do 4 z krokiem 0.5. Krańcowe wartości to -4 i 4.
"""

#Zadanie 9
'''
while True:
    liczba = int(input("Podaj licbę całcowitą: "))
    if liczba < 0:
        break

print("Działanie pętli się zalończyło")
#Pętla nieskończona wykonuje się cały czas, dopóki użytkownik jej nie przerwie.
#Wyjście nastąpi, gdy spełniony będzie warunek (np. liczba ujemna).
'''

#Zadanie 10
'''
l1 = int(input("Podaj pierwsa liczbe calcowita:"))
l2 = int(input("Podaj drugą liczbe calcowita:"))

if l1 > l2:
    l1, l2 = l2, l1

print(l1)
print(l2)
#zawsze l1< l2

while l1<=l2:
    print(l1)
    l1+=1
#Warto sprawdzić, która z liczb jest mniejsza, a która większa. 
#Pętla wypisze liczby od mniejszej do większej.
'''

#Zadanie 11
'''
l1 = int(input("Podaj pierwsa liczbe calcowita: "))
l2 = int(input("Podaj drugą liczbe calcowita: "))

if l1 > l2:
    l1, l2 = l2, l1

while l1<=l2:
    if l1 % 2 == 0:
        print(l1)
        l1 += 1
    else :
        l1 += 1
        continue
#Liczby parzyste to te, które dzielą się przez 2 bez reszty (np. x%2==0). 
#Instrukcja continue pozwala pominąć liczby nieparzyste i przejść do kolejnej iteracji.
'''

#Zadanie 12
'''
n = int(input("Podaj liczbę studentów w grupie: "))

if n <= 0:
    print("Liczba studentów musi być większa od 0.")
else:
    suma_punktów = 0
    i = 0

    while i < n:
        punkty = float(input(f"Podaj liczbę punktów dla studenta {i + 1}: "))
        suma_punktów += punkty
        i += 1

    średnia = suma_punktów / n

    print(f"Średnia liczba punktów w grupie: {średnia:.2f}")
'''

#Zadanie 13
'''
print("Podaj liczbę punktów (0-100). Wpisz 'k', aby zakończyć.")

while True:
    wejscie = input("Podaj liczbę punktów: ")

    if wejscie.lower() == 'k':  
        print("Zakończono działanie programu.")
        break

    try:
        punkty = int(wejscie)

        if punkty < 0 or punkty > 100:
            print("Punkty muszą być w przedziale 0-100. Spróbuj ponownie.")
            continue

        print(f"Podano poprawną liczbę punktów: {punkty}")
    except ValueError:
        print("Niepoprawna wartość. Wprowadź liczbę całkowitą lub 'k'.")
'''

#Zadanie 14
#1
'''
while True:
    try:
        dana = input("Wprowadź liczbę: ")
        if dana.isdigit():  
            dana = int(dana)
            if dana > 0:
                print("To jest liczba dodatnia.")
                continue  
            else:
                print("To jest zero.")
                continue
        else:
            print("Koniec programu.")
            break  
    except ValueError:
        print("Nieprawidłowa wartość. Koniec programu.")
        break
'''
#2
'''
import math

while True:
    try:
        dana = input("Wprowadź liczbę: ")
        if dana.isdigit():  
            dana = int(dana)
            if dana >= 0:
                pierwiastek = math.sqrt(dana)
                print(f"Pierwiastek kwadratowy liczby {dana}: {pierwiastek:.2f}")
            else:
                print("Dziękujemy za skorzystanie z naszej aplikacji.")
                break  
        else:
            print("Dziękujemy za skorzystanie z naszej aplikacji.")
            break  
    except ValueError:
        print("Dziękujemy za skorzystanie z naszej aplikacji.")
        break
'''